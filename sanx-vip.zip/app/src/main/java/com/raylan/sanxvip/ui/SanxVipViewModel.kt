package com.raylan.sanxvip.ui

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.sanxvip.data.VipFeaturesCatalog
import com.raylan.sanxvip.model.VipFeature
import com.raylan.sanxvip.model.VipTab
import com.raylan.sanxvip.service.SanxKeepAliveService
import com.raylan.sanxvip.shizuku.ShizukuConnectionState
import com.raylan.sanxvip.shizuku.ShizukuManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SanxVipUiState(
  val selectedTab: VipTab = VipTab.MIRA_AVANCADA,
  val features: List<VipFeature> = VipFeaturesCatalog.allFeatures,
  val enabledFeatureIds: Set<String> = emptySet(),
  val isVipInjected: Boolean = false,
  val isInjecting: Boolean = false,
  val injectionProgress: Float = 0f,
  val injectionStageText: String = "",
  val shizukuState: ShizukuConnectionState = ShizukuConnectionState.DISCONNECTED,
  val selectedHelpFeature: VipFeature? = null,
  val statusMessage: String? = null,
) {
  val currentTabFeatures: List<VipFeature>
    get() = features.filter { it.tab == selectedTab }

  val activeCount: Int
    get() = enabledFeatureIds.size
}

class SanxVipViewModel(
  private val shizukuManager: ShizukuManager = ShizukuManager(),
) : ViewModel() {

  companion object {
    private val FREE_FIRE_PACKAGES = listOf("com.dts.freefireth", "com.dts.freefiremax")
  }

  private val _uiState = MutableStateFlow(SanxVipUiState())
  val uiState: StateFlow<SanxVipUiState> = _uiState.asStateFlow()

  init {
    shizukuManager.initialize()
    viewModelScope.launch {
      shizukuManager.connectionState.collect { state ->
        _uiState.update { it.copy(shizukuState = state) }
      }
    }
  }

  fun selectTab(tab: VipTab) {
    _uiState.update { it.copy(selectedTab = tab) }
  }

  fun openHelp(feature: VipFeature) {
    _uiState.update { it.copy(selectedHelpFeature = feature) }
  }

  fun closeHelp() {
    _uiState.update { it.copy(selectedHelpFeature = null) }
  }

  fun clearStatusMessage() {
    _uiState.update { it.copy(statusMessage = null) }
  }

  fun refreshShizuku() {
    shizukuManager.refreshState()
  }

  fun onShizukuButtonClick(context: Context) {
    val msg = shizukuManager.connectOrRequestPermission(context)
    _uiState.update { it.copy(statusMessage = msg) }
  }

  fun onFeatureSwitchChanged(feature: VipFeature, checked: Boolean) {
    val current = _uiState.value
    if (!current.isVipInjected) {
      _uiState.update {
        it.copy(
          statusMessage =
            "Toque em INJETAR CÓDIGO VIP primeiro para liberar a ativação dos módulos."
        )
      }
      return
    }

    val updatedSet =
      if (checked) {
        current.enabledFeatureIds + feature.id
      } else {
        current.enabledFeatureIds - feature.id
      }

    _uiState.update { it.copy(enabledFeatureIds = updatedSet) }

    if (checked && current.shizukuState == ShizukuConnectionState.CONNECTED) {
      viewModelScope.launch {
        runCatching { shizukuManager.executeCommands(feature.systemCommands) }
      }
    }
  }

  fun injectVipCode(context: Context) {
    if (_uiState.value.isInjecting) return

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          isInjecting = true,
          injectionProgress = 0f,
          injectionStageText = "Calibrando resposta de toque...",
        )
      }

      for (step in 1..100) {
        val stageText =
          when {
            step <= 34 -> "Calibrando resposta de toque..."
            step <= 69 -> "Estabilizando rota de ping..."
            else -> "Aplicando perfil avançado..."
          }
        _uiState.update {
          it.copy(
            injectionProgress = step / 100f,
            injectionStageText = stageText,
          )
        }
        delay(22L)
      }

      val stateBeforeApply = _uiState.value
      val commandsToApply = buildList {
        addAll(VipFeaturesCatalog.baselineVipCommands)
        stateBeforeApply.features
          .filter { it.id in stateBeforeApply.enabledFeatureIds }
          .forEach { addAll(it.systemCommands) }
      }.distinct()

      val appliedViaShizuku =
        runCatching { shizukuManager.executeCommands(commandsToApply) }.getOrDefault(false)

      SanxKeepAliveService.start(context.applicationContext)

      val gameOpened = launchFreeFireSafely(context)

      val completionMessage =
        when {
          gameOpened && appliedViaShizuku ->
            "Código VIP aplicado com Shizuku! Abrindo Free Fire..."
          gameOpened ->
            "Perfil VIP liberado e serviço ativo! Abrindo Free Fire..."
          appliedViaShizuku ->
            "Código VIP aplicado com Shizuku! Free Fire não encontrado neste aparelho."
          else ->
            "Perfil VIP liberado e proteção contínua ativada! Free Fire não encontrado."
        }

      _uiState.update {
        it.copy(
          isVipInjected = true,
          isInjecting = false,
          injectionProgress = 1f,
          injectionStageText = "",
          statusMessage = completionMessage,
        )
      }
    }
  }

  private fun launchFreeFireSafely(context: Context): Boolean {
    return runCatching {
      val pm = context.packageManager
      for (pkg in FREE_FIRE_PACKAGES) {
        val launchIntent = runCatching { pm.getLaunchIntentForPackage(pkg) }.getOrNull()
        if (launchIntent != null) {
          launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(launchIntent)
          return@runCatching true
        }
      }
      false
    }.getOrDefault(false)
  }

  override fun onCleared() {
    shizukuManager.dispose()
    super.onCleared()
  }
}
