package com.raylan.sanxvip.model

enum class VipTab(val title: String) {
  MIRA_AVANCADA("MIRA AVANÇADA (18)"),
  PING_AVANCADO("PING AVANÇADO (17)"),
}

data class VipFeature(
  val id: String,
  val index: Int,
  val name: String,
  val tab: VipTab,
  val gamerExplanation: String,
  val systemCommands: List<String>,
)
