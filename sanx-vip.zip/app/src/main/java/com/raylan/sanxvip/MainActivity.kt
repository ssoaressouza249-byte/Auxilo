package com.raylan.sanxvip

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.raylan.sanxvip.ui.SanxVipScreen
import com.raylan.sanxvip.ui.SanxVipViewModel
import com.raylan.sanxvip.ui.theme.SanxVipTheme

class MainActivity : ComponentActivity() {

  private val viewModel: SanxVipViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    runCatching {
      enableEdgeToEdge(
        statusBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
        navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
      )
    }

    setContent {
      SanxVipTheme {
        val isIntact = remember { SecurityGuard.isAppIntact(this) }
        if (!isIntact) {
          SecurityTamperScreen()
        } else {
          var askedNotification by remember { mutableStateOf(false) }
          val notificationLauncher =
            rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }

          LaunchedEffect(Unit) {
            if (!askedNotification && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
              askedNotification = true
              val granted =
                runCatching {
                  ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.POST_NOTIFICATIONS,
                  ) == PackageManager.PERMISSION_GRANTED
                }.getOrDefault(false)
              if (!granted) {
                runCatching {
                  notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
              }
            }
          }

          SanxVipScreen(viewModel = viewModel)
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    runCatching { viewModel.refreshShizuku() }
  }
}
