package com.raylan.sanxvip

import android.content.Context
import androidx.annotation.Keep
import kotlin.system.exitProcess

@Keep
class SanxShizukuUserService() : ISanxShizukuService.Stub() {

  @Suppress("UNUSED_PARAMETER")
  constructor(context: Context) : this()

  override fun destroy() {
    runCatching { exitProcess(0) }
  }

  override fun executeCommand(command: String?): Int {
    if (command.isNullOrBlank()) return -1
    return runCatching {
      val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
      runCatching { process.inputStream.bufferedReader().use { it.readText() } }
      process.waitFor()
    }.getOrDefault(-1)
  }

  override fun executeBatch(commands: Array<out String>?): Int {
    if (commands.isNullOrEmpty()) return 0
    var successCount = 0
    for (cmd in commands) {
      if (executeCommand(cmd) == 0) {
        successCount++
      }
    }
    return successCount
  }
}
