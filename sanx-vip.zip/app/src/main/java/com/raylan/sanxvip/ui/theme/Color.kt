package com.raylan.sanxvip.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val CardDark = Color(0xFF111111)
val CardActiveDark = Color(0xFF1A1A1A)
val BorderGray = Color(0xFF2A2A2A)
val PureWhite = Color(0xFFFFFFFF)
val MutedText = Color(0xFF9A9A9A)
val DisabledSurface = Color(0xFF1D1D1D)
val AlertRedDark = Color(0xFF8E0000)
val AlertRed = Color(0xFFB71C1C)
