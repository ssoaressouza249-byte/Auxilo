package com.raylan.sanxvip

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.raylan.sanxvip.ui.theme.AlertRed
import com.raylan.sanxvip.ui.theme.AlertRedDark
import com.raylan.sanxvip.ui.theme.PureBlack
import com.raylan.sanxvip.ui.theme.PureWhite

object SecurityGuard {
  private const val EXPECTED_APP_NAME = "Sanx Vip"
  private const val EXPECTED_PACKAGE_NAME = "com.raylan.sanxvip"

  fun isAppIntact(context: Context): Boolean {
    return runCatching {
      val packageMatches = context.packageName == EXPECTED_PACKAGE_NAME
      val stringResMatches = context.getString(R.string.app_name) == EXPECTED_APP_NAME
      val labelMatches =
        context.applicationInfo.loadLabel(context.packageManager).toString() == EXPECTED_APP_NAME
      packageMatches && stringResMatches && labelMatches
    }.getOrDefault(false)
  }

  fun openUninstallDialog(context: Context) {
    runCatching {
      val intent =
        Intent(Intent.ACTION_DELETE).apply {
          data = Uri.parse("package:${context.packageName}")
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
    }
  }
}

@Composable
fun SecurityTamperScreen() {
  BackHandler(enabled = true) {}
  val context = LocalContext.current

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(AlertRedDark)
        .systemBarsPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = "Alerta de segurança",
        tint = PureWhite,
        modifier = Modifier.size(64.dp),
      )

      Spacer(modifier = Modifier.height(20.dp))

      Text(
        text = "ALTERAÇÃO DETECTADA",
        style = MaterialTheme.typography.headlineSmall,
        color = PureWhite,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text =
          "Este aplicativo foi modificado fora do pacote ou nome original autorizado. Por segurança, o uso foi bloqueado.",
        style = MaterialTheme.typography.bodyMedium,
        color = PureWhite,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(28.dp))

      Button(
        onClick = { SecurityGuard.openUninstallDialog(context) },
        colors =
          ButtonDefaults.buttonColors(
            containerColor = PureWhite,
            contentColor = AlertRed,
          ),
        shape = RoundedCornerShape(10.dp),
        modifier =
          Modifier.fillMaxWidth()
            .height(54.dp)
            .testTag("uninstall_now_button"),
      ) {
        Text(
          text = "DESINSTALAR AGORA",
          style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black),
          color = PureBlack,
        )
      }
    }
  }
}
